"use client"

import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay } from "swiper/modules";
import { Card, CardBody, Img } from '@chakra-ui/react'
import 'swiper/css';
import { advantagesData } from '../data/advantages.data';

export function Advatages() {
    
    let icon = ""
    const advantageSlides = advantagesData.map((advantage, index) =>  {

        switch (index) {
            case 0:
                icon = "/cool.svg"
                break;
            case 1:
                icon = "/star.svg"
                break;
            case 2:
                icon = "/rainbow.svg"
                break;
            case 3:
                icon = "/love.svg"
                break;   
        }

        return (
            <SwiperSlide key={index} className='p-5'>
                <Card className='w-[300px] h-[150px] md:w-[400px] md:h-[200px] mx-auto opacity-80'>
                    <CardBody className="flex justify-center text-center items-center font-bold text-sm md:text-base leading-5 md:leading-8">
                        <div className="icon-text flex flex-col gap-3">
                            <Img src={icon} alt="cools" className="h-11 w-11 md:h-14 md:w-14 mx-auto" />
                            <p>{advantage}</p>
                        </div>
                    </CardBody>
                </Card>
            </SwiperSlide>
        );
    });

    return (
        <Swiper
        modules={[Autoplay]}
          spaceBetween={50}
          slidesPerView={1}
          autoplay={{
            delay: 2000
          }}
        >
          {advantageSlides}
        </Swiper>
      );
}

