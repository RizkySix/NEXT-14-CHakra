const galleriesData = [
    ['/galleries/g1.jpeg', '/galleries/g2.jpeg', '/galleries/g3.jpeg', '/galleries/g4.jpeg'],
    ['/galleries/g5.jpeg', '/galleries/g6.jpg', '/galleries/g7.jpeg', '/galleries/g8.jpeg'],
    ['/galleries/g9.jpeg', '/galleries/g10.jpeg', '/galleries/g11.jpeg', '/galleries/g12.jpeg'],
    ['/galleries/g13.jpeg', '/galleries/g14.jpeg', '/galleries/g15.jpeg', '/galleries/g16.jpeg'],
    ['/galleries/g17.jpeg', '/galleries/g18.jpeg', '/galleries/g19.jpeg', '/galleries/g20.jpeg'],
    ['/galleries/g21.jpeg', '/galleries/g22.jpeg', '/galleries/g23.jpg', '/galleries/g24.jpg'],
  ];
  

export { galleriesData }
