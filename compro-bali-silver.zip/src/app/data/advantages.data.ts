const advantagesData = [
    "Exquisite Craftsmanship: Elevate creations with precision and artistry.",
    "Timeless Elegance: Embrace the enduring beauty of silver craftsmanship.",
    "Customization Options: Explore endless personalization possibilities.",
    "Prestigious Quality: Deliver ornaments exuding luxury and sophistication."
]

export { advantagesData }
